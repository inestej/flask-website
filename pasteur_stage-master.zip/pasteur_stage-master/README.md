# Flask Application

## Prerequisites

Before you begin, ensure you have met the following requirements:
- You have installed Python 3.7 or later.
- You have installed `pip`, the Python package installer.

## Installation

To install the required packages, follow these steps:

1. Create a virtual environment:

    ```sh
    python3 -m venv venv
    ```

2. Activate the virtual environment:

    ```sh
    # On Windows
    venv\Scripts\activate

    # On Unix or MacOS
    source venv/bin/activate
    ```

3. Install the required packages:

    ```sh
    pip install -r requirements.txt
    ```

## Running the Web_site in any IDE:
  1.Open the app.py:
  
  ![image](https://github.com/dridi1/pasteur_stage/assets/107431733/3fc072e8-da31-43b2-8d52-0a038ff6f9eb)

  2.Run the app.py:

  ![image](https://github.com/dridi1/pasteur_stage/assets/107431733/b1860faf-3c14-405c-8a44-50d9685f377c)
  
  3.Go to http://127.0.0.1:5000 or http://192.168.1.70:5000 (Default port 5000)

  ![image](https://github.com/dridi1/pasteur_stage/assets/107431733/6cc8142a-cd1f-4e04-8551-04d7233e8e0f)

![image](https://github.com/dridi1/pasteur_stage/assets/107431733/a58c974e-f457-4efd-95ee-f2712cef6d16)



