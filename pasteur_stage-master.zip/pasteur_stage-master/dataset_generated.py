import pandas as pd
import random

# Sample data for governorates and delegations in Tunisia
governorates = [
    "Tunis", "Ariana", "Ben Arous", "Manouba",
    "Zaghouan", "Bizerte", "Beja", "Jendouba", "Kef",
    "Siliana"
]

delegations = [
    'Siliana Nord', 'Siliana Sud', "M'Hamdia", 'Laroussa', 'Zriba', 'Lake Ichkeul', 'Bizerte Sud', 
    'Bir Mchergua', 'Bargou', 'Amdoun', 'Béja Sud', 'Téboursouk', 
    'Béja Nord', 'Goubellat', 'Mejez El Bab', 'Thibar', 'Testour', 
    'Bizerte Nord', 'Joumine', 'Mateur', 'Menzel Bourguiba', 'Sidi Thabet', 
    'Utique', 'Jendouba Sud', 'Jendouba Nord', 'Fahs', 'Kalaat El Andalous', 
    'Dahmani', 'Kef Est', 'Kef Ouest', 'Nebeur', 'Zaghouan',
    'Borj El Amri', 'Oued Ellil', 'El Battan', 'Jedaida', 'Tebourba',
    'El Krib'
]

# Mapping of delegations to governorates
delegations_mapping = {
    "Tunis": ["M'Hamdia"],
    "Ariana": ['Sidi Thabet', 'Kalaat El Andalous'],
    "Ben Arous": ['Bir Mchergua'],
    "Manouba": ['Borj El Amri', 'Oued Ellil', 'El Battan', 'Jedaida', 'Tebourba'],
    "Zaghouan": ['Zriba', 'Fahs', 'Zaghouan'],
    "Bizerte": ['Lake Ichkeul', 'Bizerte Sud', 'Bizerte Nord', 'Joumine', 'Mateur', 'Menzel Bourguiba', 'Utique'],
    "Beja": ['Amdoun', 'Béja Sud', 'Téboursouk', 'Béja Nord', 'Goubellat', 'Mejez El Bab', 'Thibar', 'Testour'],
    "Jendouba": ['Jendouba Sud', 'Jendouba Nord'],
    "Kef": ['Dahmani', 'Kef Est', 'Kef Ouest', 'Nebeur'],
    "Siliana": ['Siliana Nord', 'Siliana Sud', 'Laroussa', 'Bargou', 'El Krib']
}

# Seed types and their varieties
seed_types = [
    {"seed_type_id": 1, "seed_name": "BD"},
    {"seed_type_id": 2, "seed_name": "BT"},
    {"seed_type_id": 3, "seed_name": "Or"},
    {"seed_type_id": 4, "seed_name": "Tr"}
]

varieties = {
    "BD": ["salim", "maali", "nasr", "karim", "razzek", "khiar", "om rabiaa", "inrat100", "inrat69", "mahmoud", "dhahbi", "chelli"],
    "BT": ["tahent", "haidra", "utique", "vaga", "byrsa", "salamboo", "ariana66", "frank"],
    "Or": ["kounouz", "imen", "rihane", "manel", "imene"],
    "Tr": ["triticale82", "triticale83", "tcl8", "tcl13", "khir"]
}

def generate_land_data(num_records):
    land_data = []
    for i in range(1, num_records + 1):
        governorate = random.choice(governorates)
        delegation = random.choice(delegations_mapping[governorate])
        record = {
            "id_land": i,
            "governorate": governorate,
            "delegation": delegation,
            "latitude": round(random.uniform(33.0, 37.0), 6),
            "longitude": round(random.uniform(7.0, 11.0), 6),
            "area(m²)": random.randint(1000, 100000)
        }
        land_data.append(record)
    return land_data

def generate_owner_data(num_records):
    owner_data = []
    for i in range(1, num_records + 1):
        record = {
            "owner_id": i,
            "name": f"Owner {i}"
        }
        owner_data.append(record)
    return owner_data

def generate_land_owner_data(land_data, owner_data, seed_types):
    land_owner_data = []
    id_counter = 1
    for land in land_data:
        for _ in range(random.randint(1, 3)):
            owner_id = random.choice(owner_data)["owner_id"]
            record = {
                "id": id_counter,
                "land_id": land["id_land"],
                "owner_id": owner_id,
                "year": random.randint(2000, 2023),
                "seed_type_id": random.choice(seed_types)["seed_type_id"],
                "initial_num_seed": random.randint(100, 10000),
                "final_production": random.randint(100, 10000)
            }
            land_owner_data.append(record)
            id_counter += 1
    return land_owner_data

# Generate data
land_data = generate_land_data(100)
owner_data = generate_owner_data(50)
land_owner_data = generate_land_owner_data(land_data, owner_data, seed_types)

# Convert to DataFrames
df_land = pd.DataFrame(land_data)
df_owner = pd.DataFrame(owner_data)
df_land_owner = pd.DataFrame(land_owner_data)
df_seed_type = pd.DataFrame([
    {"seed_type_id": seed["seed_type_id"], "seed_name": seed["seed_name"], "variety": variety}
    for seed in seed_types
    for variety in varieties[seed["seed_name"]]
])



df_land.to_excel('D:/project_stage/data/land.xlsx', index=False)
df_owner.to_excel('D:/project_stage/data/owner.xlsx', index=False)
df_land_owner.to_excel('D:/project_stage/data/land_owner.xlsx', index=False)
df_seed_type.to_excel('D:/project_stage/data/seed_type.xlsx', index=False)
